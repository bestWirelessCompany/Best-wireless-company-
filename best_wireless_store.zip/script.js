
function selectProduct(productName) {
    document.getElementById('selectedProduct').value = productName;
    document.getElementById('orderForm').style.display = 'block';
    window.scrollTo(0, document.body.scrollHeight);
}

document.getElementById('orderForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('https://formsubmit.co/ajax/taiwo.samuel.123890@gmail.com', {
        method: 'POST',
        headers: { 'Accept': 'application/json' },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.success === "true") {
            document.getElementById('orderForm').style.display = 'none';
            document.getElementById('confirmation').style.display = 'block';
        } else {
            alert("Something went wrong. Please try again.");
        }
    });
});
